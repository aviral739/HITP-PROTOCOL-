// =======================================================
// HITP — Human Intent Transfer Protocol
// Version 2.3 (Stable + Ollama + Sliding Window)
// =======================================================

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const fetch = require("node-fetch");

// =======================================================
// DATABASE (Protocol Memory Layer)
// =======================================================
const db = new sqlite3.Database("memory.db", (err) => {
  if (err) console.error("DB Error:", err);
  else console.log("🟢 HITP Memory Layer ready");
});

// Base table
db.run(`
  CREATE TABLE IF NOT EXISTS memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    port INTEGER,
    intent TEXT,
    action TEXT,
    compiled TEXT
  )
`);

// =======================================================
// EXPRESS
// =======================================================
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "5mb" }));

// =======================================================
// HEALTH CHECK
// =======================================================
app.get("/api/health", (req, res) => {
  res.json({
    status: "online",
    protocol: "HITP/2.3",
    ai: "Gemini Intent Compiler",
    uptime: process.uptime(),
    memory: "connected"
  });
});

// =======================================================
// OLLAMA INTENT COMPILER (LOCAL AI) — FIXED & WORKING
// =======================================================
async function compileIntentWithOllama(text) {
  const ollamaUrl = "http://127.0.0.1:11434";

  try {
    const r = await fetch(`${ollamaUrl}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "mistral",
        stream: false,
        temperature: 0.2,
        prompt: `
You are a strict JSON API.
Respond with ONLY valid JSON.
No explanations. No markdown.

User input:
"${text}"

Return exactly this JSON:
{
  "intent": "",
  "category": "education|travel|shopping|search|media|productivity|other",
  "confidence": 0.0,
  "reasoning": "",
  "suggestedAction": ""
}
`
      })
    });

    if (!r.ok) return null;

    const data = await r.json();
    const raw = data.response;
    if (!raw) return null;

    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return null;

    return JSON.parse(match[0]);

  } catch (e) {
    return null;
  }
}

// =======================================================
// CORE HITP PIPELINE WITH OSI LAYER VISUALIZATION
// =======================================================
app.post("/api/intent", async (req, res) => {
  try {
    const text = (req.body.text || "").trim();
    if (!text) return res.status(400).json({ error: "Empty intent" });

    const SRC_IP = req.ip || "192.168.1.10";
    const DST_IP = "142.250.183.110";
    const PORT = 443;
    const SRC_MAC = "AA:BB:CC:DD:EE:FF";
    const DST_MAC = "11:22:33:44:55:66";

    console.log("\n" + "=".repeat(70));
    console.log("🌐 HITP REQUEST RECEIVED");
    console.log("=".repeat(70));
    console.log("TIME :", new Date().toISOString());
    console.log("USER :", text);
    console.log("=".repeat(70));

    // ========== LAYER 1 ==========
    console.log("\n📡 LAYER 1: PHYSICAL LAYER (Electrical Signals)");
    console.log("   ├─ Signal Type: Digital Binary");
    console.log("   ├─ Frequency: 2.4 GHz (WiFi)");
    console.log("   ├─ Voltage: 3.3V Logic");
    console.log("   └─ Status: ✓ Connected");
    console.log("   ✅ LAYER 1 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 2 ==========
    console.log("🔗 LAYER 2: DATA LINK LAYER (MAC Addressing & Frames)");
    console.log(`   ├─ Source MAC: ${SRC_MAC}`);
    console.log(`   ├─ Dest MAC: ${DST_MAC}`);
    console.log(`   ├─ Frame Type: Ethernet II`);
    console.log(`   ├─ Frame Size: ${text.length + 54} bytes`);
    console.log("   ├─ Frames Transmitted:");
    for (let i = 1; i <= 3; i++) {
      console.log(`   │  └─ Frame ${i}: [${Math.random().toString(16).slice(2, 8).toUpperCase()}] Sent ✓`);
    }
    console.log("   └─ Status: ✓ Frames Forwarded");
    console.log("   ✅ LAYER 2 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 3 ==========
    console.log("🌍 LAYER 3: NETWORK LAYER (IP Routing & Packets)");
    console.log(`   ├─ Source IP: ${SRC_IP}`);
    console.log(`   ├─ Dest IP: ${DST_IP}`);
    console.log(`   ├─ Protocol: TCP/IP`);
    console.log(`   ├─ TTL: 64`);
    console.log("   ├─ Routing Path:");
    console.log(`   │  └─ Router 1 (192.168.1.1) ──> Router 2 (10.0.0.1) ──> Internet Gateway`);
    console.log("   ├─ Packets Created:");
    const packetSize = Math.ceil(text.length / 1460);
    for (let i = 1; i <= Math.min(packetSize, 3); i++) {
      console.log(`   │  └─ Packet ${i}: Seq=${(i - 1) * 1460}, Size=1460B, Route=OK ✓`);
    }
    console.log("   └─ Status: ✓ Packets Routed");
    console.log("   ✅ LAYER 3 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 4 ==========
    console.log("📨 LAYER 4: TRANSPORT LAYER (TCP Segmentation & Ports)");
    console.log(`   ├─ Source Port: ${Math.floor(Math.random() * 65535)}`);
    console.log(`   ├─ Dest Port: ${PORT}`);
    console.log(`   ├─ Protocol: TCP`);
    console.log("   ├─ Connection Handshake:");
    console.log("   │  ├─ [SYN] ──────────────────> (Initiating...)");
    console.log("   │  ├─ [SYN-ACK] <──────────── (Acknowledged)");
    console.log("   │  └─ [ACK] ──────────────────> (Connected) ✓");

    console.log("   ├─ Sliding Window Protocol (Sender → Receiver):");
    console.log("   │");
    const windowSize = 4;
    const dataLength = Math.ceil(text.length / 30);

    for (let seq = 0; seq < dataLength; seq += windowSize) {
      console.log(`   │  Seq ${seq}:`);
      let senderWindow = "   │  Sender  │";
      let receiverWindow = "   │  Receiver│";

      for (let i = 0; i < windowSize; i++) {
        if (seq + i < dataLength) {
          senderWindow += ` [${seq + i}]`;
          receiverWindow += ` [ ]`;
        }
      }
      senderWindow += " ──>";
      receiverWindow += " <──";

      console.log(senderWindow);
      console.log(receiverWindow);
      console.log(`   │  ACK ← Window Ack=${Math.min(seq + windowSize, dataLength)}`);
      console.log("   │");
    }

    console.log("   └─ Status: ✓ TCP Connection Established");
    console.log("   ✅ LAYER 4 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 5 ==========
    console.log("\n🔐 LAYER 5: SESSION LAYER (Session Management)");
    console.log("   ├─ Session ID: " + Date.now());
    console.log("   ├─ Session Start: " + new Date().toISOString());
    console.log("   ├─ User Agent: HITP/1.0 Protocol");
    console.log("   └─ Status: ✓ Session Active");
    console.log("   ✅ LAYER 5 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 6 ==========
    console.log("🎨 LAYER 6: PRESENTATION LAYER (Data Encryption & Formatting)");
    console.log("   ├─ Encryption: TLS 1.3");
    console.log("   ├─ Data Format: UTF-8 JSON");
    console.log("   └─ Status: ✓ Data Formatted");
    console.log("   ✅ LAYER 6 EXECUTED SUCCESSFULLY\n");

    // ========== LAYER 7 ==========
    console.log("🧠 LAYER 7: APPLICATION LAYER (Ollama Processing & Intent Recognition)");
    console.log(`   ├─ Raw Intent: "${text}"`);
    console.log("   ├─ Processing Start...");

    let action = "🔍 Generic Google Search";
    let redirect = `https://www.google.com/search?q=${encodeURIComponent(text)}`;

    const compiled = await compileIntentWithOllama(text);

    if (compiled) {
      console.log("   ├─ ✓ AI Compiled Intent");
      console.log(`   │  ├─ Intent: ${compiled.intent}`);
      console.log(`   │  ├─ Category: ${compiled.category}`);
      console.log(`   │  ├─ Confidence: ${(compiled.confidence * 100).toFixed(0)}%`);
      console.log(`   │  └─ Suggested: ${compiled.suggestedAction}`);
    } else {
      console.log("   ├─ ✓ Using Keyword Matching (AI unavailable)");
    }

    // ===== AI → ACTION HANDOFF =====
if (compiled && compiled.category) {
  switch (compiled.category) {
    case "education":
      action = "🎓 Redirecting to Educational Resource";
      redirect = "https://www.google.com/search?q=" + encodeURIComponent(text);
      break;

    case "travel":
      action = "✈️ Redirecting to Travel Booking";
      redirect = "https://www.makemytrip.com";
      break;

    case "shopping":
      action = "🛒 Redirecting to Shopping Platform";
      redirect = "https://www.amazon.in";
      break;

    case "media":
      action = "🎬 Redirecting to Media Platform";
      redirect = "https://www.youtube.com";
      break;

    case "productivity":
      action = "📄 Redirecting to Productivity Tool";
      redirect = "https://docs.google.com";
      break;

    default:
      // keep default Google search
      break;
  }
}

    setImmediate(() => {
      db.run(
        `INSERT INTO memory (timestamp, src_ip, dst_ip, port, intent, compiled, action)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          new Date().toISOString(),
          SRC_IP,
          DST_IP,
          PORT,
          text,
          compiled ? JSON.stringify(compiled) : null,
          action
        ]
      );
    });

    res.json({
      ai_compiled: compiled,
      action,
      redirect,
      status: "executed"
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =======================================================
// MEMORY FETCH
// =======================================================
app.get("/api/memory", (req, res) => {
  db.all("SELECT * FROM memory ORDER BY id DESC LIMIT 20", (err, rows) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(rows || []);
  });
});

// =======================================================
// START SERVER
// =======================================================
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`🚀 HITP Protocol Server running on http://127.0.0.1:${PORT}`);
});
