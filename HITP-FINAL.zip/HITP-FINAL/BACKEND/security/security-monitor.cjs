// =======================================================
// HITP — Human Intent Transfer Protocol
// Version 2.3 (Stable + Ollama + Sliding Window)
// =======================================================

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const fetch = require("node-fetch");

// =======================================================
// DATABASE (Protocol Memory Layer)
// =======================================================
const db = new sqlite3.Database("memory.db", (err) => {
  if (err) console.error("DB Error:", err);
  else console.log("🟢 HITP Memory Layer ready");
});

// Base table
db.run(`
  CREATE TABLE IF NOT EXISTS memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    port INTEGER,
    intent TEXT,
    action TEXT,
    compiled TEXT
  )
`);

// Intent Cache (NO user data stored)
db.run(`
  CREATE TABLE IF NOT EXISTS intent_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    intent_key TEXT UNIQUE,
    action TEXT,
    redirect TEXT
  )
`);

// =======================================================
// EXPRESS
// =======================================================
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "5mb" }));

// =======================================================
// HEALTH CHECK
// =======================================================
app.get("/api/health", (req, res) => {
  res.json({
    status: "online",
    protocol: "HITP/2.3",
    uptime: process.uptime(),
    memory: "connected"
  });
});

// =======================================================
// OLLAMA INTENT COMPILER (LOCAL AI)
// =======================================================
async function compileIntentWithOllama(text) {
  const ollamaUrl = "http://127.0.0.1:11434";

  try {
    const r = await fetch(`${ollamaUrl}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "mistral",
        stream: false,
        temperature: 0.2,
        prompt: `
You are a strict JSON API.
Respond with ONLY valid JSON.

User input:
"${text}"

Return exactly this JSON:
{
  "intent": "",
  "category": "education|travel|shopping|search|media|productivity|other",
  "confidence": 0.0,
  "reasoning": "",
  "suggestedAction": ""
}
`
      })
    });

    if (!r.ok) return null;
    const data = await r.json();
    const match = data.response?.match(/\{[\s\S]*\}/);
    if (!match) return null;

    return JSON.parse(match[0]);
  } catch {
    return null;
  }
}

// =======================================================
// INTENT KEY GENERATOR (NO USER DATA STORED)
// =======================================================
function generateIntentKey(text) {
  const t = text.toLowerCase();
  if (t.includes("bus")) return "travel_bus";
  if (t.includes("train")) return "travel_train";
  if (t.includes("movie")) return "media_movie";
  if (t.includes("flight")) return "travel_flight";
  if (t.includes("shopping") || t.includes("buy")) return "shopping";
  return "generic";
}

// =======================================================
// CORE HITP PIPELINE
// =======================================================
app.post("/api/intent", async (req, res) => {
  try {
    const text = (req.body.text || "").trim();
    if (!text) return res.status(400).json({ error: "Empty intent" });

    const SRC_IP = req.ip || "192.168.1.10";
    const DST_IP = "142.250.183.110";
    const PORT = 443;

    console.log("\n🌐 HITP REQUEST:", text);

    // ================= LAYER 7 =================
    const intentKey = generateIntentKey(text);

    const cached = await new Promise((resolve) => {
      db.get(
        "SELECT * FROM intent_cache WHERE intent_key = ?",
        [intentKey],
        (_, row) => resolve(row || null)
      );
    });

    let compiled = null;

    if (!cached) {
      console.log("🧠 First-time intent → AI invoked");
      compiled = await compileIntentWithOllama(text);
    } else {
      console.log("⚡ Learned intent → AI skipped");
    }

    let action = cached?.action || "🔍 Generic Google Search";
    let redirect =
      cached?.redirect ||
      `https://www.google.com/search?q=${encodeURIComponent(text)}`;

    const t = text.toLowerCase();
    if (t.includes("train")) {
      action = "🚂 Redirecting to IRCTC";
      redirect = "https://www.irctc.co.in";
    } else if (t.includes("bus")) {
      action = "🚌 Redirecting to RedBus";
      redirect = "https://www.redbus.in";
    } else if (t.includes("movie")) {
      action = "🎬 Redirecting to BookMyShow";
      redirect = "https://in.bookmyshow.com";
    }

    if (!cached) {
      db.run(
        `INSERT OR IGNORE INTO intent_cache (intent_key, action, redirect)
         VALUES (?, ?, ?)`,
        [intentKey, action, redirect]
      );
      console.log("📚 Intent learned (no user data stored)");
    }

    db.run(
      `INSERT INTO memory (timestamp, src_ip, dst_ip, port, intent, compiled, action)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(),
        SRC_IP,
        DST_IP,
        PORT,
        text,
        compiled ? JSON.stringify(compiled) : null,
        action
      ]
    );

    res.json({
      intent: text,
      intent_key: intentKey,
      ai_used: !cached,
      action,
      redirect
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =======================================================
// START SERVER
// =======================================================
app.listen(5000, () => {
  console.log("🚀 HITP Server running on http://127.0.0.1:5000");
});
