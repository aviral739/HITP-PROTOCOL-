// =======================================================
// HITP — Human Intent Transfer Protocol
// Version 2.3 (Stable + Ollama + Sliding Window)
// =======================================================

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const fetch = require("node-fetch");

// =======================================================
// DATABASE (Protocol Memory Layer)
// =======================================================
const db = new sqlite3.Database("memory.db", (err) => {
  if (err) console.error("DB Error:", err);
  else console.log("🟢 HITP Memory Layer ready");
});

// Base table
db.run(`
  CREATE TABLE IF NOT EXISTS memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    port INTEGER,
    intent TEXT,
    action TEXT,
    compiled TEXT
  )
`);

// =======================================================
// EXPRESS
// =======================================================
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "5mb" }));

// =======================================================
// HEALTH CHECK
// =======================================================
app.get("/api/health", (req, res) => {
  res.json({
    status: "online",
    protocol: "HITP/2.3",
    ai: "Gemini Intent Compiler",
    uptime: process.uptime(),
    memory: "connected"
  });
});

// =======================================================
// OLLAMA INTENT COMPILER (LOCAL AI)
// =======================================================
// =======================================================
// OLLAMA INTENT COMPILER (LOCAL AI) — FIXED & WORKING
// =======================================================
async function compileIntentWithOllama(text) {
  const ollamaUrl = "http://127.0.0.1:11434";

  try {
    const r = await fetch(`${ollamaUrl}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "mistral",
        stream: false,
        temperature: 0.2,
        prompt: `
You are a strict JSON API.
Respond with ONLY valid JSON.
No explanations. No markdown.

User input:
"${text}"

Return exactly this JSON:
{
  "intent": "",
  "category": "education|travel|shopping|search|media|productivity|other",
  "confidence": 0.0,
  "reasoning": "",
  "suggestedAction": ""
}
`
      })
    });

    if (!r.ok) return null;

    const data = await r.json();
    const raw = data.response;
    if (!raw) return null;

    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return null;

    const parsed = JSON.parse(match[0]);
    console.log("[OLLAMA] ✓ Intent compiled with reasoning");
    return parsed;

  } catch (e) {
    console.log("[OLLAMA] Unavailable - using keyword matching");
    return null;
  }
}


// =======================================================
// CORE HITP PIPELINE WITH OSI LAYER VISUALIZATION
// =======================================================
app.post("/api/intent", async (req, res) => {
  try {
    const text = (req.body.text || "").trim();
    if (!text) return res.status(400).json({ error: "Empty intent" });

    // Simulated network metadata
    const SRC_IP = req.ip || "192.168.1.10";
    const DST_IP = "142.250.183.110";
    const PORT = 443;
    const SRC_MAC = "AA:BB:CC:DD:EE:FF";
    const DST_MAC = "11:22:33:44:55:66";

    console.log("\n" + "=".repeat(70));
    console.log("🌐 HITP REQUEST RECEIVED");
    console.log("=".repeat(70));
    console.log("TIME :", new Date().toISOString());
    console.log("USER :", text);
    console.log("=".repeat(70));

    // ========== LAYER 1: PHYSICAL LAYER ==========
    console.log("\n📡 LAYER 1: PHYSICAL LAYER (Electrical Signals)");
    console.log("   ├─ Signal Type: Digital Binary");
    console.log("   ├─ Frequency: 2.4 GHz (WiFi)");
    console.log("   ├─ Voltage: 3.3V Logic");
    console.log("   └─ Status: ✓ Connected");
    console.log("   ✅ LAYER 1 EXECUTED SUCCESSFULLY\n");
    

    // ========== LAYER 2: DATA LINK LAYER ==========
    console.log("🔗 LAYER 2: DATA LINK LAYER (MAC Addressing & Frames)");
    console.log(`   ├─ Source MAC: ${SRC_MAC}`);
    console.log(`   ├─ Dest MAC: ${DST_MAC}`);
    console.log(`   ├─ Frame Type: Ethernet II`);
    console.log(`   ├─ Frame Size: ${text.length + 54} bytes`);
    console.log("   ├─ Frames Transmitted:");
    for (let i = 1; i <= 3; i++) {
      console.log(`   │  └─ Frame ${i}: [${Math.random().toString(16).slice(2, 8).toUpperCase()}] Sent ✓`);
    }
    console.log("   └─ Status: ✓ Frames Forwarded");
    console.log("   ✅ LAYER 2 EXECUTED SUCCESSFULLY\n");
     

    // ========== LAYER 3: NETWORK LAYER ==========
    console.log("🌍 LAYER 3: NETWORK LAYER (IP Routing & Packets)");
    console.log(`   ├─ Source IP: ${SRC_IP}`);
    console.log(`   ├─ Dest IP: ${DST_IP}`);
    console.log(`   ├─ Protocol: TCP/IP`);
    console.log(`   ├─ TTL: 64`);
    console.log("   ├─ Routing Path:");
    console.log(`   │  └─ Router 1 (192.168.1.1) ──> Router 2 (10.0.0.1) ──> Internet Gateway`);
    console.log("   ├─ Packets Created:");
    const packetSize = Math.ceil(text.length / 1460);
    for (let i = 1; i <= Math.min(packetSize, 3); i++) {
      console.log(`   │  └─ Packet ${i}: Seq=${(i-1)*1460}, Size=1460B, Route=OK ✓`);
    }
    console.log("   └─ Status: ✓ Packets Routed");
    console.log("   ✅ LAYER 3 EXECUTED SUCCESSFULLY\n");
     

    // ========== LAYER 4: TRANSPORT LAYER ==========
    console.log("📨 LAYER 4: TRANSPORT LAYER (TCP Segmentation & Ports)");
    console.log(`   ├─ Source Port: ${Math.floor(Math.random()*65535)}`);
    console.log(`   ├─ Dest Port: ${PORT}`);
    console.log(`   ├─ Protocol: TCP`);
    console.log("   ├─ Connection Handshake:");
    console.log("   │  ├─ [SYN] ──────────────────> (Initiating...)");
    console.log("   │  ├─ [SYN-ACK] <──────────── (Acknowledged)");
    console.log("   │  └─ [ACK] ──────────────────> (Connected) ✓");
    
    // Sliding Window Animation
    console.log("   ├─ Sliding Window Protocol (Sender → Receiver):");
    console.log("   │");
    const windowSize = 4;
    const dataLength = Math.ceil(text.length / 30);
    
    for (let seq = 0; seq < dataLength; seq += windowSize) {
      console.log(`   │  Seq ${seq}:`);
      let senderWindow = "   │  Sender  │";
      let receiverWindow = "   │  Receiver│";
      
      for (let i = 0; i < windowSize; i++) {
        if (seq + i < dataLength) {
          senderWindow += ` [${seq + i}]`;
          if (seq + i < seq - 1) {
            receiverWindow += ` [✓]`;
          } else {
            receiverWindow += ` [ ]`;
          }
        }
      }
      senderWindow += " ──>";
      receiverWindow += " <──";
      
      console.log(senderWindow);
      console.log(receiverWindow);
      console.log(`   │  ACK ← Window Ack=${seq + windowSize > dataLength ? dataLength : seq + windowSize}`);
      console.log("   │");
    }
    
    console.log("   ├─ Segments:");
    console.log(`   │  ├─ Segment 1: Data="${text.substring(0, 30)}..." (Seq=0)`);
    console.log(`   │  ├─ ACK Received: Ack=1 ✓`);
    console.log(`   │  └─ Window Size: 65535 bytes`);
    console.log("   └─ Status: ✓ TCP Connection Established");
    console.log("   ✅ LAYER 4 EXECUTED SUCCESSFULLY\n");
    

    // ========== LAYER 5: SESSION LAYER ==========
    console.log("\n🔐 LAYER 5: SESSION LAYER (Session Management)");
    console.log("   ├─ Session ID: " + Date.now());
    console.log("   ├─ Session Start: " + new Date().toISOString());
    console.log("   ├─ User Agent: HITP/1.0 Protocol");
    console.log("   ├─ Authentication: ✓ Verified");
    console.log("   ├─ Dialog Control: Half-Duplex (Request/Response)");
    console.log("   └─ Status: ✓ Session Active");
    console.log("   ✅ LAYER 5 EXECUTED SUCCESSFULLY\n");
    

    // ========== LAYER 6: PRESENTATION LAYER ==========
    console.log("🎨 LAYER 6: PRESENTATION LAYER (Data Encryption & Formatting)");
    console.log("   ├─ Encryption: TLS 1.3");
    console.log("   ├─ Data Format: UTF-8 JSON");
    console.log("   ├─ Compression: Enabled");
    console.log("   ├─ Character Encoding: ✓ Verified");
    console.log("   └─ Status: ✓ Data Formatted");
    console.log("   ✅ LAYER 6 EXECUTED SUCCESSFULLY\n");
    

    // ========== LAYER 7: APPLICATION LAYER ==========
    console.log("🧠 LAYER 7: APPLICATION LAYER (Ollama Processing & Intent Recognition)");
    console.log("   ├─ Protocol: HITP v2.3 (Human Intent Transfer Protocol)");
    console.log(`   ├─ Raw Intent: "${text}"`);
    console.log("   ├─ AI Model: Mistral 7B");
    console.log("   ├─ Processing Start...");

    // Call Ollama for AI thinking (optional)
    let compiled;
    try {
      compiled = await compileIntentWithOllama(text);
    } catch (e) {
      console.error("Ollama call error:", e);
      compiled = null;
    }
    
    if (compiled) {
      console.log(`   ├─ ✓ AI Compiled Intent`);
      console.log(`   │  ├─ Intent: "${compiled.intent}"`);
      console.log(`   │  ├─ Category: ${compiled.category}`);
      console.log(`   │  ├─ Confidence: ${(compiled.confidence * 100).toFixed(0)}%`);
      console.log(`   │  └─ Suggested: ${compiled.suggestedAction}`);
    } else {
      console.log("   ├─ ✓ Using Keyword Matching (AI unavailable)");
    }
    console.log("   └─ Status: ✓ Intent Processed");
    console.log("   ✅ LAYER 7 EXECUTED SUCCESSFULLY\n");
    console.log("   ollama does not store user data only processes intent .");
    console.log("   ollama disconnected after intent  processing .")
    

    // ========== INTELLIGENT ROUTING (KEYWORD-BASED) ========
    console.log("\n🎯 INTELLIGENT ROUTING ");
    
    let action = "🔍 Generic Google Search";
    let redirect = `https://www.google.com/search?q=${encodeURIComponent(text)}`;
    const textLower = text.toLowerCase();

    // Train booking
    if (textLower.includes("train") || textLower.includes("railway") || textLower.includes("irctc")) {
      action = "🚂 Redirecting to IRCTC - Train Booking Portal";
      redirect = "https://www.irctc.co.in";
    }
    // Bus booking
    else if (textLower.includes("bus") || textLower.includes("redbus")) {
      action = "🚌 Redirecting to RedBus - Bus Booking";
      redirect = "https://www.redbus.in";
    }
    // Flight booking
    else if (textLower.includes("flight") || textLower.includes("plane") || textLower.includes("air ticket")) {
      action = "✈️  Redirecting to MakeMyTrip - Flight Booking";
      redirect = "https://www.makemytrip.com";
    }
    // Amazon shopping
    else if (textLower.includes("amazon") || textLower.includes("shopping") || textLower.includes("buy ") || textLower.includes("purchase")) {
      action = "🛒 Redirecting to Amazon Shopping Portal";
      redirect = "https://www.amazon.in";
    }
    // Flipkart
    else if (textLower.includes("flipkart")) {
      action = "🏪 Redirecting to Flipkart";
      redirect = "https://www.flipkart.com";
    }
    // YouTube
    else if (textLower.includes("youtube") || textLower.includes("video") || textLower.includes("watch") || textLower.includes("funny")) {
      action = "🎬 Redirecting to YouTube - Video Streaming";
      redirect = "https://www.youtube.com";
    }
    // Netflix
    else if (textLower.includes("netflix") || textLower.includes("movie") || textLower.includes("series") || textLower.includes("show")) {
      action = "📺 Redirecting to Netflix - Streaming Service";
      redirect = "https://www.netflix.com";
    }
    // Spotify
    else if (textLower.includes("spotify") || textLower.includes("music") || textLower.includes("song") || textLower.includes("listen")) {
      action = "🎵 Redirecting to Spotify - Music Streaming";
      redirect = "https://www.spotify.com";
    }
    // Gmail
    else if (textLower.includes("gmail") || textLower.includes("email") || textLower.includes("mail send")) {
      action = "📧 Redirecting to Gmail - Email Service";
      redirect = "https://mail.google.com";
    }
    // Google Drive
    else if (textLower.includes("drive") || textLower.includes("storage") || textLower.includes("cloud")) {
      action = "☁️  Redirecting to Google Drive - Cloud Storage";
      redirect = "https://drive.google.com";
    }
    // Google Docs
    else if (textLower.includes("docs") || textLower.includes("document") || textLower.includes("write")) {
      action = "📄 Redirecting to Google Docs - Document Editor";
      redirect = "https://docs.google.com";
    }

    console.log(`   ├─ Matched Intent: RECOGNIZED`);
    console.log(`   ├─ Action: ${action}`);
    console.log(`   ├─ Target URL: ${redirect}`);
    console.log("   └─ Status: ✓ Ready to Redirect");

    // ========== SESSION LAYER: STORE MEMORY ==========
    console.log("\n💾 DATABASE: Storing Intent in Memory");
    
    // Store in DB (non-blocking)
    setImmediate(() => {
      db.run(`
        INSERT INTO memory
        (timestamp, src_ip, dst_ip, port, intent, compiled, action)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        new Date().toISOString(),
        SRC_IP,
        DST_IP,
        PORT,
        text,
        compiled ? JSON.stringify(compiled) : null,
        action
      ], (err) => {
        if (err) console.error("❌ DB Error:", err);
        else {
          console.log("   ├─ Intent stored with ID: [Auto-incremented]");
          console.log("   └─ Status: ✓ Memory Updated");
        }
      });
    });
    
    console.log("   ├─ Intent queued for storage");
    console.log("   └─ Status: ✓ Pending Write");

    // ========== FINAL RESPONSE ==========
    console.log("\n" + "=".repeat(70));
    console.log("✓ HITP PROCESSING COMPLETE");
    console.log("=".repeat(70) + "\n");

    res.json({
      parsed: { 
        intent: text,
        ai_thinking: compiled ? {
          reasoning: compiled.reasoning,
          confidence: compiled.confidence,
          category: compiled.category
        } : null
      },
      ai_compiled: compiled,
      action,
      redirect,
      status: "executed"
    });
  } catch (error) {
    console.error("❌ ENDPOINT ERROR:", error);
    res.status(500).json({ error: error.message });
  }
});

// =======================================================
// MEMORY FETCH
// =======================================================
app.get("/api/memory", (req, res) => {
  db.all("SELECT * FROM memory ORDER BY id DESC LIMIT 20", (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows || []);
    }
  });
});

// =======================================================
// START SERVER
// =======================================================
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`🚀 HITP Protocol Server running on http://127.0.0.1:${PORT}`);
});